#include <iostream>
#include <cmath>
using namespace std;

double F(double x)
{
	return pow(x,3) + (3 * pow(x,2)) + (12 * x) + 8;
}

int main(){
	setlocale(LC_ALL, "Rus");
	double x1, x2, otvet=0, y, E = 0.01;
	x1 = 4;
	x2 = 9;
	do{
		y = otvet;
		otvet = x2 - (((x2 - x1) * F(x2)) / (F(x2) - F(x1)));
		x1 = x2;
		x2 = otvet;
	}while (fabs(y - otvet) >= E);
	cout << "�����: " << otvet << endl;
	system("pause");
	return 0;
}